<!doctype html>
<html lang="{{ config('app.locale') }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 120vh;
                margin: 0;
            }

          hlp1 {
    word-spacing: 422px;
    font-size: 70px;
  /*  letter-spacing: 12rem; */
  }

          hlp2 {
    word-spacing: 92px;
    font-size: 30px;
  }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }


            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;

            }

          .image1st{
              position: absolute;
              <!--margin-top: 330px;-->
              right: 5px;
              top: 200px;

            }

            .titledamn {
                position: absolute;
                right: 95px;
                top: 5px;
              /*  text-align: top-right; */
                letter-spacing: .12rem;
                background-color: #636b6f;
                color: #fff;
                /*margin-top: -200px;
                margin-left: 20px;
                margin-right: 20px;*/
                text-decoration: none;
                padding: 20px;

            }

            /*.links > a {
                display: inline-block;
                color: #636b6f;
                padding: 25px;
                margin top : -120px;
                position: absolute;
                top: 300px;

                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 20px;
            }*/
            .footer{
                position: absolute;
                text-align: center;
                top: 560px;
                align-items: center;
                width: auto;
                font-weight: 800;

            }
            .links1 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 1100px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links2 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 915px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links3 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 800px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links4 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 630px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links5 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 500px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links6 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 250px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links7 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 100px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }

        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @if (Auth::check())
                        <a href="{{ url('/welcome') }}">Home</a>
                    @else
                        <a href="/Sign in">Login</a>
                        <a href="{{ url('/product') }}">welcome2</a>
                    @endif
                </div>
            @endif

            <div class="content">
                    <div class="links1">
                        <a href="https://laravel.com/docs">Hours</a>
                    </div>
                    <div class="links2">
                        <a href="https://laracasts.com">Virtual Mall</a>
                    </div>
                    <div class="links3">
                    <a href="https://laravel-news.com">Shops</a>
                    </div>
                    <div class="links4">
                    <a href="{{ url('/product') }}">Products</a>
                    </div>
                    <div class="links5">
                    <a href="https://github.com/laravel/laravel">offers</a>
                    </div>
                    <div class="links6">
                    <a href="/">Discussion Forum</a>
                    </div>
                    <div class="links7">
                    <a href="/">About us </a>
                    </div>
            </div>
            <div class="footer">
         address: Road A, block B, Dhaka <br>  To contact us: <br> <a href="mailto:someone@example.com">mailto:someone@example.com</a>
        </div>

            <div class="titledamn">
              <strong>
                    <hlp1>
                        <a herf="http://localhost:8000/users"> ShopAssistant<a/>
                      </hlp1>
                <hlp2>
                    <a "/register"> Samin</a>
                    <a "/register"> Register</a>
                  </hlp2>
                </strong>
            </div>
            <div class="image1st">
             <img src="http://alliswall.com/file/10305/1920x1200/16:9/colorful_shopping_center_architecture.jpg" width = "1110" height="300" alt="naruto">
        </div>
        </div>
  </body>
</html>
