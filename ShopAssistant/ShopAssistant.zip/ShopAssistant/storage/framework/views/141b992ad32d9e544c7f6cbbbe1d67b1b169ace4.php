<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #f2f2f2;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 300vh;
                margin: 0;
            }

          hlp1 {
    word-spacing: 422px;
    font-size: 70px;
  /*  letter-spacing: 12rem; */
  }

          hlp2 {
    word-spacing: 92px;
    font-size: 30px;
  }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }


            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                background: 20px;
                background-color: yellow;
                text-align: center;

            }
            .content2{
                background: 20px;
                background-color: #0000a0;
                text-align: center;
            }

            .titledamn {
                position: absolute;
                right: 95px;
                top: 5px;
              /*  text-align: top-right; */
                letter-spacing: .12rem;
                background-color: #636b6f;
                color: #fff;
                /*margin-top: -200px;
                margin-left: 20px;
                margin-right: 20px;*/
                text-decoration: none;
                padding: 20px;

            }

            .vertical-menu {
                width: 280px;
                position: absolute;
                top: 380px;
                right: 22px;
                margin: 8px 0;
                padding: 12px 20px;
                display: inline-block;
                border: 1px solid #ccc;
                box-sizing: border-box;
                border-radius: 4px;
            }


            /*.links > a {
                display: inline-block;
                color: #636b6f;
                padding: 25px;
                margin top : -120px;
                position: absolute;
                top: 300px;

                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 20px;
            }*/
            .footer{
                color: #000000;
                position: absolute;
                text-align: center;
                top: 1800px;
                align-items: center;
                width: auto;
                font-weight: 800;

            }
            .links1 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 1100px;
                background: 20px;
                background-color: #e3c3c3;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links2 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 40px;
                right: 915px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links3 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 780px;
                background-color: #e3c3c3;
                padding-right: 40px;
                padding-left: 40px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links4 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 630px;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 52px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links5 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 500px;
                top: 130px;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 50px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links6 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 250px;
                top: 130px;
                font-size: 15px;
                background: 15px;
                background-color: #e3c3c3;
                padding-left: 50px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links7 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 100px;
                top: 130px;
                font-size: 15px;
                background: 20px;
                background-color: #e3c3c3;
                font-weight: 800;
                padding-left: 50px;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links10 {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 800px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px;
            }

            .links11  {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 424px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 24px;
            }
            .links9  {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 300px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px;
            }
            input[type=text] {
                position: absolute;
                top: 260px;
                right:400px;
                width: 430px;
                box-sizing: border-box;
                border: 1px solid #000000;
                border-radius: 4px;                    font-size: 16px;
                background-color: white;
                background-image: url('http://findicons.com/files/icons/117/radium/128/search.png');
                background-position: 10px 10px;
                background-repeat: no-repeat;
                background-size: 30px,20px;
                padding: 12px 20px 12px 40px;
                -webkit-transition: width 0.4s ease-in-out;
                transition: width 0.4s ease-in-out;
            }

            input[type=text]:focus {
                width: 100%;
            }
            .showimage2 {
                position: absolute;
                top: 380px;
                right:930px;
            }
            .caption2 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 665px;
              right: 900px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage3 {
                position: absolute;
                top: 380px;
                right:630px;
            }

            .caption3 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 665px;
              right: 700px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage4 {
                position: absolute;
                top: 380px;
                right:330px;
            }

            .caption4 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 665px;
              right: 370px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage5 {
                position: absolute;
                top: 800px;
                right:930px;
            }
            .caption5 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 1085px;
              right: 970px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage6 {
                position: absolute;
                top: 800px;
                right:630px;
            }
            .caption6 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 1085px;
              right: 670px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage7 {
                position: absolute;
                top: 800px;
                right:330px;
            }
            .caption7 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 1085px;
              right: 370px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage8 {
                position: absolute;
                top: 1220px;
                right:930px;
            }
            .caption8 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 1505px;
              right: 970px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage9 {
                position: absolute;
                top: 1220px;
                right:630px;
            }
            .caption9 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 1505px;
              right: 670px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }
            .showimage10 {
                position: absolute;
                top: 1220px;
                right:330px;
            }
            .caption10 > a {
              color: #0000a0;
              padding: 25px;
              position: absolute;
              top: 1505px;
              right: 370px;
              font-size: 15px;
              font-weight: 600;

              letter-spacing: .1rem;
              text-decoration: none;
              text-transform: uppercase;
              word-spacing: 2px;
            }

        </style>
    </head>
    <body>
        <form>
            <input type="text" name="search" placeholder="Search Products..">
        </form>

        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/welcome')); ?>">Home</a>
                    <?php else: ?>
                        <a href="/Sign in">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                    <div class="links1">
                        <a href="https://laravel.com/docs">Hours</a>
                    </div>
                    <div class="links2">
                        <a href="https://laracasts.com">Virtual Mall</a>
                    </div>
                    <div class="links3">
                        <a href="https://laravel-news.com">Shops</a>
                    </div>
                    <div class="links4">
                        <a href="http://localhost:8000/users">Products</a>
                    </div>
                    <div class="links5">
                        <a href="https://github.com/laravel/laravel">offers</a>
                    </div>
                    <div class="links6">
                        <a href="/">Discussion Forum</a>
                    </div>
                    <div class="links7">
                        <a href="/">About us </a>
                    </div>


            </div>
            <div class ="content2">
                    <div class="links9">
                        Grab A Bite <br>
                    </div>
                    <div class="links10">
                        Newly Arrived
                    </div>
                    <div class="links11">
                        Men Women Kids Gadgets Lifestyle
                    </div>
            </div>
            <div class="footer">
                address: Road A, block B, Dhaka <br>  To contact us: <br> <a href="mailto:someone@example.com">mailto:someone@example.com</a>
            </div>

            <div class="titledamn">
              <strong>
                    <hlp1>
                        <a "/users"> ShopAssistant<a/>
                      </hlp1>
                <hlp2>
                    <a "/register"> Samin</a>
                    <a "/register"> Register</a>
                  </hlp2>
                </strong>
            </div>
        </div>
        <div class = "images9">
          <div class="showimage2">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/3kz6ZkNg9ihyBML4/source_photo.jpg?auto=compress%2Cformat&w=540&h=675&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption2">
            <a href="/product1"> <strong> Abercrombie & FitchIcon </strong> <br> Long-Sleeve Tee <br> $20 </a>
          </div>
          <div class="showimage3">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/hrbHb78gCyiUcKio/source_photo.jpg?auto=compress%2Cformat&w=540&h=269.15625&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption3">
            <a href="/product10"> <strong> Ray Ban  </strong> <br> Sunglass <br> $90 </a>
          </div>
          <div class="showimage4">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/lbCqc_5Ys99Sst0K/source_photo.jpg?auto=compress%2Cformat&w=540&h=540&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption4">
            <a href="/product11"> <strong> Tiroll  </strong> <br> Backpack <br> $25 </a>
          </div>
          <div class="showimage5">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/ijs8zHOcS-I1VzTO/source_photo.jpg?auto=compress%2Cformat&w=540&h=686.5714285714286&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption5">
            <a href="/product1"> <strong> Sweater </strong> <br> Dress <br> $15 </a>
          </div>
          <div class="showimage6">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/lVMXod59sts40k33/source_photo.jpg?auto=compress%2Cformat&w=540&h=686.5714285714286&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption6">
             <a href="/product1"> <strong> Hawai t-shirt </strong> <br>Woman dress<br> $10 </a>
          </div>
          <div class="showimage7">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/szu2xRAH0OSJyKPY/source_photo.jpg?auto=compress%2Cformat&w=540&h=540&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption7">
            <a href="/product1"> <strong> Long tops </strong> <br>Woman dress<br> $18 </a>
          </div>
          <div class="showimage8">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/9Mp_9E7CadyrAtFf/source_photo.jpg?auto=compress%2Cformat&w=540&h=540&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption8">
             <a href="/product1"> <strong> Long gown </strong> <br>Woman dress<br> $25 </a>
          </div>
          <div class="showimage9">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/4lA8t3OL72yOs2iM/source_photo.jpg?auto=compress%2Cformat&w=540&h=398.52000000000004&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption9">
            <a href="/product1"> <strong> Life of colors </strong>  <br>Art<br> $30 </a>
          </div>
          <div class="showimage10">
            <img src="https://crawler-cache-jellolabs-com.imgix.net/Qln4YFAjoHky3Iu0/source_photo.jpg?auto=compress%2Cformat&w=540&h=540&fit=clip" width="250" height="300" alt="Shirt">
          </div>
          <div class="caption10">
            <a href="/product1"> <strong> Black polo </strong> <br>t-shirt<br> $10 </a>
          </div>

        </div>
          <select class="vertical-menu"id="country" name="country">
              <option value="Sort">Sort By</option>
              <option value="Popularity">Popularity</option>
              <option value="Prices">price</option>
              <option value="Floor">floor</option>
              <option value="Shop">Shop</option>

          </select>
  </body>
</html>
