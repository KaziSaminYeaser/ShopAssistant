<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #f2f2f2;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 300vh;
                margin: 0;
            }

          hlp1 {
    word-spacing: 422px;
    font-size: 70px;
  /*  letter-spacing: 12rem; */
  }

          hlp2 {
    word-spacing: 92px;
    font-size: 30px;
  }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }


            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                background: 20px;
                background-color: yellow;
                text-align: center;

            }
            .content2{
                background: 20px;
                background-color: #0000a0;
                text-align: center;
            }

            .titledamn {
                position: absolute;
                right: 95px;
                top: 5px;
              /*  text-align: top-right; */
                letter-spacing: .12rem;
                background-color: #636b6f;
                color: #fff;
                /*margin-top: -200px;
                margin-left: 20px;
                margin-right: 20px;*/
                text-decoration: none;
                padding: 20px;

            }

            .vertical-menu {
                width: 280px;
                position: absolute;
                top: 380px;
                right: 22px;
            }

            .vertical-menu a {
                  background-color: #eee;
                  color: black;
                  display: block;
                  padding: 12px;
                  text-decoration: none;
                }

                .vertical-menu a:hover {
                    background-color: #ccc;
                }

                .vertical-menu a.active {
                    background-color: #4CAF50;
                    color: white;
                }

            /*.links > a {
                display: inline-block;
                color: #636b6f;
                padding: 25px;
                margin top : -120px;
                position: absolute;
                top: 300px;

                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 20px;
            }*/
            .footer{
                color: #000000;
                position: absolute;
                text-align: center;
                top: 1800px;
                align-items: center;
                width: auto;
                font-weight: 800;

            }
            .links1 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 1100px;
                background: 20px;
                background-color: #e3c3c3;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links2 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 40px;
                right: 915px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links3 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 780px;
                background-color: #e3c3c3;
                padding-right: 40px;
                padding-left: 40px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links4 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 630px;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 52px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links5 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 500px;
                top: 130px;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 50px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links6 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 250px;
                top: 130px;
                font-size: 15px;
                background: 15px;
                background-color: #e3c3c3;
                padding-left: 50px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links7 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 100px;
                top: 130px;
                font-size: 15px;
                background: 20px;
                background-color: #e3c3c3;
                font-weight: 800;
                padding-left: 50px;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links10 {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 800px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px;
            }

            .links11  {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 424px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 24px;
            }
            .links9  {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 300px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px;
            }
            .Name  {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 100px;
                top: 340px;
                font-size: 25px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px;
            }


            .button {
                  background-color: #008CBA;
                  border: none;
                  color: white;
                  padding: 15px 32px;
                  text-align: center;
                  text-decoration: none;
                  display: inline-block;
                  font-size: 16px;
                  font-weight: 800px
                  margin: 4px 2px;
                  cursor: pointer;
                  duration: 0.4s; /* Safari */
                  transition-duration: 0.4s;
                  cursor: pointer;

              }
              .button1 {
                  position: absolute;
                  top: 510px;
                  right: 180px;
                  width: 250px;
                  border-radius: 8px;
                  background-color: #008CBA;
                  color: white;
              }

              .button1:hover {
                background-color: white;
                color: black;
                border: 2px solid #008CBA;
              }

              .button2{
                position: absolute;
                top: 580px;
                right: 180px;
                width: 250px;
                background-color: #4caf50;
                color: white;
                border-radius: 8px;
              }
              .button2:hover {
                background-color: white;
                color: black;
                border: 2px solid #4caf50;
              }

              .para {
                color: #000000;
                padding: 25px;
                position: absolute;
                top: 660px;
                right: 110px;
                font-size: 10px;
                font-weight: 900;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px
              }


            input[type=text] {
                position: absolute;
    /*            top: 260px;
                right:400px;
                width: 430px; */
                box-sizing: border-box;
                border: 1px solid #000000;
                border-radius: 4px;
                font-size: 16px;
                background-color: white;
               /*background-image: url('http://findicons.com/files/icons/117/radium/128/search.png');*/
                background-position: 10px 10px;
                background-repeat: no-repeat;
                background-size: 30px,20px;
                padding: 12px 20px 12px 40px;
                /*-webkit-transition: width 0.4s ease-in-out;
                transition: width 0.4s ease-in-out;*/
            }
            .searchBox {
                top: 260px;
                right:400px;
                width: 430px;

            }


            .show2 {
              position: absolute;
              top: 400px;
              right:730px;
            }
            .footer{
                color: #000000;
                position: absolute;
                text-align: center;
                top: 1800px;
                align-items: center;
                width: auto;
                font-weight: 800;

            }
            .city {
                display: none;
            }
            input[type=submit] {
                width: 300px;
                background-color: #4CAF50;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            select {
                width: 400px;
                position: absolute;
                top: 200px;
                left: 450px;
                margin: 8px 0;
                padding: 12px 20px;
                display: inline-block;
                border: 1px solid #ccc;
                box-sizing: border-box;
                border-radius: 4px;



            }
            input[type=submit]:hover {
                background-color: #45a049;
            }
            /* Set a style for all buttons */
            button {
                background-color: #4CAF50;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                cursor: pointer;
                width: 100%;
            }

            button:hover {
                colour: black;
                opacity: 0.4;
            }

            /* Extra styles for the cancel button */
            .cancelbtn {
                background-color: #f44336;
                padding-bottom: 10px;
                position: absolute;
                top: 530px;
                left: 500px;
                width: 300px;
                border-radius: 4px;

            }

            .cancelbtn2 {
                background-color: #f44336;
                padding-bottom: 10px;
                position: absolute;
                top: 530px;
                left: 520px;
                width: 300px;
                border-radius: 4px;

            }
            .cancelbtn3 {
                background-color: #f44336;
                padding-bottom: 10px;
                position: absolute;
                top: 300px;
                left: 520px;
                width: 300px;
                border-radius: 4px;

            }

            .submitbtn{
                background-color: #008CBA;
                padding-bottom: 10px;
                position: absolute;
                top: 480px;
                left: 500px;
                width: 300px;
                border-radius: 4px;

            }

            .submitbtn2{
                background-color: #008CBA;
                padding-bottom: 10px;
                position: absolute;
                top: 480px;
                left: 520px;
                width: 300px;
                border-radius: 4px;

            }

            .container {
                padding: 5px;
            }

            span.psw {
                float: right;
                padding-top: 16px;
            }

            /* The Modal (background) */
            .modal {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                left: 600;
                top: 500;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                padding-top: 60px;
            }
            .modal2 {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                left: 600;
                top: 500;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                padding-top: 60px;
            }
            .modal3 {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                left: 600;
                top: 600;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                padding-top: 60px;
            }

            /* Modal Content/Box */
            .modal-content {
                background-color: #fefefe;
                margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
                border: 1px solid #888;
                border-radius: 4px;
                height:500px;
                width: 500px; /* Could be more or less, depending on screen size */
            }
            .modal2-content {
                background-color: #fefefe;
                margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
                border: 1px solid #888;
                border-radius: 4px;
                height:500px;
                width: 400px; /* Could be more or less, depending on screen size */
            }
            .modal3-content {
                background-color: #fefefe;
                margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
                border: 1px solid #888;
                border-radius: 4px;
                height:250px;
                width: 400px; /* Could be more or less, depending on screen size */
            }



            .axa{
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 170px;
                left: 443px;
                color: #000000;
                font-size: 13px;
                font-weight: 900;
                letter-spacing: .05rem;
                text-decoration: none;
                word-spacing: 2px;
            }
            .axa3{
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 332px;
                left: 443px;
                color: #000000;
                font-size: 13px;
                font-weight: 900;
                letter-spacing: .05rem;
                text-decoration: none;
                word-spacing: 2px;
            }
            .axa4{
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 248px;
                left: 443px;
                color: #000000;
                font-size: 13px;
                font-weight: 900;
                letter-spacing: .05rem;
                text-decoration: none;
                word-spacing: 2px;
            }
            .axa2 {
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 170px;
                left: 503px;
                color: #0000a0;
                font-size: 15px;
                font-weight: 500;
                letter-spacing: .05rem;
                word-spacing: 2px;
            }
            .axa7 {
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 170px;
                left: 523px;
                color: #0000a0;
                font-size: 15px;
                font-weight: 500;
                letter-spacing: .05rem;
                word-spacing: 2px;
            }

            .axa5 {
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 323px;
                left: 490px;
                color: #0000a0;
                font-size: 15px;
                font-weight: 500;
                letter-spacing: .05rem;
                word-spacing: 2px;
            }

            .ndInp {
                width: 400px;
                position: absolute;
                top: 285px;
                left: 450px;
                padding: 12px 20px;
                border: 1px solid #555;
                outline: none;
            }
            .ndInp:focus {
                width: 410px;
                background-color: lightblue;
            }
            .ndInp2 {
                width: 400px;
                position: absolute;
                top: 370px;
                left: 450px;
                padding: 12px 20px;
                font-size: 15px;
                border: 1px solid #555;
                outline: none;
            }
            .ndInp2:focus {
                width: 410px;
                background-color: lightblue;
            }

            .ndInp3 {
                width: 300px;
                position: absolute;
                top: 370px;
                left: 494px;
                padding: 12px 20px;
                border: 1px solid #555;
                outline: none;
            }
            .ndInp3:focus {
                width: 310px;
                background-color: lightblue;
            }


        </style>
    </head>
    <body>
        <form>
            <input type="text" class="searchBox" name="search" placeholder="Search Products..">
        </form>

        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/welcome')); ?>">Home</a>
                    <?php else: ?>
                        <a href="/Sign in">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>


            <div class="content">
                    <div class="links1">
                        <a href="https://laravel.com/docs">Hours</a>
                    </div>
                    <div class="links2">
                        <a href="https://laracasts.com">Virtual Mall</a>
                    </div>
                    <div class="links3">
                        <a href="https://laravel-news.com">Shops</a>
                    </div>
                    <div class="links4">
                        <a href="http://localhost:8000/users">Products</a>
                    </div>
                    <div class="links5">
                        <a href="https://github.com/laravel/laravel">offers</a>
                    </div>
                    <div class="links6">
                        <a href="/">Discussion Forum</a>
                    </div>
                    <div class="links7">
                        <a href="/">About us </a>
                    </div>


            </div>
            <div class ="content2">
                    <div class="links9">
                        Grab A Bite <br>
                    </div>
                    <div class="links10">
                        Newly Arrived
                    </div>
                    <div class="links11">
                        Men Women Kids Gadgets Lifestyle
                    </div>
            </div>
            <div class="footer">
                address: Road A, block B, Dhaka <br>  To contact us: <br> <a href="mailto:someone@example.com">mailto:someone@example.com</a>
            </div>

            <div class="titledamn">
              <strong>
                    <hlp1>
                        <a "/users"> ShopAssistant<a/>
                      </hlp1>
                <hlp2>
                    <a "/register"> Samin</a>
                    <a "/register"> Register</a>
                  </hlp2>
                </strong>
            </div>
            <div class="show2">
              <img src="https://crawler-cache-jellolabs-com.imgix.net/3kz6ZkNg9ihyBML4/source_photo.jpg?auto=compress%2Cformat&w=540&h=675&fit=clip" width=400px height=500px alt="Shirt">
            </div>
            <div class="Name">
                <p> ABERCROMBIE & FITCHICON <br> Type: LONG-SLEEVE TEE  <br> Price: $20 </p>
            </div>
            <a class="button button1" onclick="document.getElementById('id01').style.display='block'"><strong>Place Order</strong></a>
            <a href="https://www.google.com" class="button button2"><strong>Add to Cart</strong></a>
            <div class="para">
              <p> <h2> Product Details: </h2> <br> <br>
              Be ready for seasonal changes and in-between weather. <br> With lightweight construction and essential features,<br> this tee has you covered outside.</br><br>
              Available Size: M,L<br>
              Colour: Blue,Black
              Materials: <br>
              - 86% Polyester, 14% Cotton <br>
              - Plain Weave <br>
              - Unlined <br>
              - Zip and snap front closures <br>
              - Drawstring hood <br>
              - Hand pockets with snap button flaps <br>
              - Imported <br>
              FIT AND SIZING <br>
              - Relaxed fit <br?
              - Hits below the hip </p>
            </div>
            <div id="id01" class="modal">

              <form class="modal-content animate" action="/action_page.php">


                <div class="container">
                    <div class="axa">
                        <label><b>Select Shop <br> <br></b></label>
                    </div>

                    <div class="axa3">
                        <label><b> Contact Number <br> <br></b></label>
                    </div>

                    <div class="axa4">
                        <label><b> Delivery Address <br> <br></b></label>
                    </div>

                    <select id="country" name="country">
                        <option value="australia">Levi's</option>
                        <option value="canada">Infinity</option>
                        <option value="usa">Ecstacy</option>
                        <option value="cana">Yellow</option>
                        <option value="rich">Richman</option>
                    </select>
                        <input type="text" class="ndInp" id="lname" name="lname" >
                        <input type="text" class="ndInp2" id="lname2" name="lname2" >


                </div>

                <div class="container">
                    <button type="button" onclick="document.getElementById('id01').style.display='none';document.getElementById('id02').style.display='block'" class="submitbtn">Place Order</button>
                  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
                </div>
              </form>
            </div>

            <div id="id02" class="modal2">

              <form class="modal2-content animate" action="/action_page.php">


                <div class="container">
                    <div class="axa2">
                        <label>

                            <b>
                                Your order has been placed.<br>
                                Enter Password to Confirm Offer: <br>
                            </b>
                        </label>
                    </div>
                    <div class="axa5">
                        <label><b> Password <br> <br></b></label>
                    </div>
                    <input type="password" class="ndInp3" id="lname" name="lname">

                </div>

                <div class="container">
                  <button type="button" onclick="document.getElementById('id02').style.display='none';document.getElementById('id03').style.display='block'" class="submitbtn2">Confirm Order</button>
                  <button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn2">Exit</button>
                </div>
              </form>
            </div>

            <div id="id03" class="modal3">

              <form class="modal3-content animate" action="/action_page.php">


                <div class="container">
                    <div class="axa7">
                        <label>
                            <b>
                                Thanks for buying our product.<br>
                            </b>
                        </label>
                    </div>

                </div>

                <div class="container">
                  <button type="button" onclick="document.getElementById('id03').style.display='none'" class="cancelbtn3">Close</button>
                </div>
              </form>
            </div>


            <script>
            var modal = document.getElementById('id01');
            var modal2 = document.getElementById('id02');
            var modal3 = var modal2 = document.getElementById('id03');
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                    modal2.style.display = "none";
                    modal3.style.display = "none";
                }
            }
            </script>

        </div>
  </body>
</html>
