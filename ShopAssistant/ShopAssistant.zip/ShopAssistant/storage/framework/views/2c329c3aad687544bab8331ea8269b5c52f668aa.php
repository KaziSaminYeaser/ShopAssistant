<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css"> 
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #f2f2f2;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 120vh;
                margin: 0;
            }

          hlp1 {
    word-spacing: 422px;
    font-size: 70px;
  /*  letter-spacing: 12rem; */
  }

          hlp2 {
    word-spacing: 92px;
    font-size: 30px;
  }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }


            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                background: 20px;
                background-color: yellow;
                text-align: center;

            }
            .content2{
                background: 20px;
                background-color: #0000a0;
                text-align: center;
            }

            .titledamn {
                position: absolute;
                right: 95px;
                top: 5px;
              /*  text-align: top-right; */
                letter-spacing: .12rem;
                background-color: #636b6f;
                color: #fff;
                /*margin-top: -200px;
                margin-left: 20px;
                margin-right: 20px;*/
                text-decoration: none;
                padding: 20px;

            }

            /*.links > a {
                display: inline-block;
                color: #636b6f;
                padding: 25px;
                margin top : -120px;
                position: absolute;
                top: 300px;

                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 20px;
            }*/
            .footer{
                color: #000000;
                position: absolute;
                text-align: center;
                top: 560px;
                align-items: center;
                width: auto;
                font-weight: 800;

            }
            .links1 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 1100px;
                background: 20px;
                background-color: #e3c3c3;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links2 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 40px;
                right: 915px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links3 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 780px;
                background-color: #e3c3c3; 
                padding-right: 40px; 
                padding-left: 40px;              
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links4 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 630px;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 52px;
                top: 130px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links5 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 500px;
                top: 130px;
                background: 20px;
                background-color: #e3c3c3;
                padding-left: 50px;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 10px;
            }
            .links6 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 250px;
                top: 130px;
                font-size: 15px;
                background: 15px;
                background-color: #e3c3c3;
                padding-left: 50px;
                font-weight: 800;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links7 > a {
                color: #636b6f;
                padding: 25px;
                position: absolute;
                right: 100px;
                top: 130px;
                font-size: 15px;
                background: 20px;
                background-color: #e3c3c3;
                font-weight: 800;
                padding-left: 50px;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 5px;
            }
            .links10 {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 800px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px;
            }

            .links11  {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 424px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 24px;
            }
            .links9  {
                color: #0000a0;
                padding: 25px;
                position: absolute;
                right: 300px;
                top: 195px;
                font-size: 10px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
                word-spacing: 3px;
            }
            input[type=text] {
                position: absolute;
                top: 260px;
                right:400px;
                width: 430px;
                box-sizing: border-box;
                border: 1px solid #000000;
                border-radius: 4px;                    font-size: 16px;
                background-color: white;
                background-image: url('http://findicons.com/files/icons/117/radium/128/search.png');
                background-position: 10px 10px; 
                background-repeat: no-repeat;
                background-size: 30px,20px;
                padding: 12px 20px 12px 40px;
                -webkit-transition: width 0.4s ease-in-out;
                transition: width 0.4s ease-in-out;
            }

            input[type=text]:focus {
                width: 100%;
            }
            .button {
                background-color: #008CBA;
                border: none;
                color: white;
                padding: 15px 32px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                font-weight: 800px;
                margin: 4px 2px;
                cursor: pointer;
                position: absolute;
                top: 400px;
                duration: 0.4s; /* Safari */
                transition-duration: 0.4s;
                cursor: pointer;

            }
            .button1 {
                width: 250px;
                border-radius: 8px;
                background-color: white; 
                color: black; 
                border: 2px solid #008CBA;
            }

            .button1:hover {
                background-color: #008CBA;
                color: white;
            }
            .city {
                display: none;
            }
            input[type=submit] {
                width: 300px;
                background-color: #4CAF50;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            select {
                width: 400px;
                position: absolute;
                top: 200px;
                left: 450px;
                margin: 8px 0;
                padding: 12px 20px;
                display: inline-block;
                border: 1px solid #ccc;
                box-sizing: border-box;
                border-radius: 4px;

                

            }
            input[type=submit]:hover {
                background-color: #45a049;
            }
            /* Set a style for all buttons */
            button {
                background-color: #4CAF50;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                cursor: pointer;
                width: 100%;
            }

            button:hover {
                colour: black;
                opacity: 0.4;
            }

            /* Extra styles for the cancel button */
            .cancelbtn {
                background-color: #f44336;
                padding-bottom: 10px;
                position: absolute;
                top: 350px;
                left: 500px;
                width: 300px;
                border-radius: 4px;

            }
            .submitbtn{
                background-color: #008CBA;
                padding-bottom: 10px;
                position: absolute;
                top: 300px;
                left: 500px;
                width: 300px;
                border-radius: 4px;

            }

            .container {
                padding: 5px;

            }

            span.psw {
                float: right;
                padding-top: 16px;
            }

            /* The Modal (background) */
            .modal {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                left: 600;
                top: 500;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                padding-top: 60px;
            }

            /* Modal Content/Box */
            .modal-content {
                background-color: #fefefe;
                margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
                border: 1px solid #888;
                border-radius: 4px;
                height:300px;
                width: 500px; /* Could be more or less, depending on screen size */
            }
            

            .axa{
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 170px;
                left: 443px;
                color: #000000;
                font-size: 13px;
                font-weight: 900;
                letter-spacing: .05rem;
                text-decoration: none;
                word-spacing: 2px;
            }
            .axa2 {
                padding-top: 20px;
                padding-right: 10px;
                padding-left: 10px;
                padding-bottom: 2px;
                position: absolute;
                top: 170px;
                left: 443px;
                color: #0000a0;
                font-size: 15px;
                font-weight: 500;
                letter-spacing: .05rem;
                word-spacing: 2px;
            }

        </style>
    </head>
    <body>
        <form>
            <input type="text" name="search" placeholder="Search Products..">
        </form>

        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/welcome')); ?>">Home</a>
                    <?php else: ?>
                        <a href="/Sign in">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content"> 
                    <div class="links1">              
                        <a href="https://laravel.com/docs">Hours</a>                
                    </div>
                    <div class="links2">
                        <a href="https://laracasts.com">Virtual Mall</a>
                    </div>
                    <div class="links3">
                        <a href="https://laravel-news.com">Shops</a>
                    </div>
                    <div class="links4">
                        <a href="http://localhost:8000/users">Products</a>
                    </div>
                    <div class="links5">
                        <a href="https://github.com/laravel/laravel">offers</a>
                    </div>
                    <div class="links6">
                        <a href="/">Discussion Forum</a>
                    </div>
                    <div class="links7">
                        <a href="/">About us </a>
                    </div>

                    
            </div>
            <div class ="content2">
                    <div class="links9">
                        Grab A Bite <br>
                    </div>
                    <div class="links10">
                        Newly Arrived
                    </div>
                    <div class="links11">
                        Men Women Kids Gadgets Lifestyle
                    </div>
            </div>
            <div class="footer">
                address: Road A, block B, Dhaka <br>  To contact us: <br> <a href="mailto:someone@example.com">mailto:someone@example.com</a>
            </div>

            <div class="titledamn">
              <strong>
                    <hlp1>
                        <a herf="http://localhost:8000/users"> ShopAssistant<a/>
                      </hlp1>
                <hlp2>
                    <a "/register"> Samin</a>
                    <a "/register"> Register</a>
                  </hlp2>
                </strong>
            </div>
            <a class="button button1" onclick="document.getElementById('id01').style.display='block'"><strong>Add to Cart</strong></a>
            <!--<button class = "bttn" onclick="document.getElementById('id01').style.display='block'">Login</button> -->

            <div id="id01" class="modal">
              
              <form class="modal-content animate" action="/action_page.php">


                <div class="container">
                    <div class="axa">
                        <label>
                            <b>
                                Select Shop <br> <br>   
                            </b>
                        </label>
                    </div>
                    <select id="country" name="country">
                        <option value="australia">Australia</option>
                        <option value="canada">Canada</option>
                        <option value="usa">USA</option>
                    </select>
                
                    
                </div>

                <div class="container">
                    <button type="button" onclick="document.getElementById('id01').style.display='none';document.getElementById('id02').style.display='block'" class="submitbtn">Place Order</button>
                  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
                </div>
              </form>
            </div>

            <div id="id02" class="modal">
              
              <form class="modal-content animate" action="/action_page.php">


                <div class="container">
                    <div class="axa2">
                        <label>
                            <b>
                                Your order has been placed. Thanks for your order. <br> <br>   
                            </b>
                        </label>
                    </div>
                    
                </div>

                <div class="container">
                  <button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">Exit</button>
                </div>
              </form>
            </div>

            <script>
            var modal = document.getElementById('id01');
            var modal2 = document.getElementById('id02');
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                    modal2.style.display = "none";
                }
            }
            </script>
            
        </div>
  </body>
</html>
