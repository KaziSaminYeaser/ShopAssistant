<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/login', function () {
    return view('login');
});
Route::get('/product', function () {
    return view('welcome2');
});
Route::get('/product1', function () {
    return view('product1');
});
Route::get('/ordeer', function () {
    return view('order');
});

Route::get('/product10', function () {
    return view('product10');
});

Route::get('/product11', function () {
    return view('product11');
});
